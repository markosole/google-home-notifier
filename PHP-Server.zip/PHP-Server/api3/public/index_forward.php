<?php

$device =  $_REQUEST['device'];
$userDt = $_REQUEST['userdata'];

$servername = "localhost";
$username = "YOUR_USER";
$password = "YOUR_PASSWORD";
$dbname = "DATABASE_NAME";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->query("SET NAMES utf8");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//$sql = "INSERT INTO baza_arduino (device, userkey)
//VALUES ('".$device ."', '".$userkey ."')";
// Create connection
$conn2 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
} 

$sql2 = "SELECT storedDNS FROM storedns WHERE tb_id = '".$device."'";
$result2 = $conn2->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
    // echo $row2["storedDNS"] . "/google-home-notifier/?text=" . $userDt . "</br>";
    // $url = $row2["storedDNS"] . '/google-home-notifier/?text=' . $userDt;
    // url example: http://home.reflectdev.host/api3/public/index_forward.php?device=1&userdata=Marko
    //set POST variables
    $url = $row2["storedDNS"] . '/google-home-notifier/?text=' . $userDt;
      
    function callAPI($method, $url, $data){
           $curl = curl_init();
           switch ($method){
              case "POST":
                 curl_setopt($curl, CURLOPT_POST, 1);
                 if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                 break;
              case "PUT":
                 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                 if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);                         
                 break;
              default:
                 if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
           }
           // OPTIONS:
           curl_setopt($curl, CURLOPT_URL, $url);
           curl_setopt($curl, CURLOPT_HTTPHEADER, array(
              'APIKEY: 111111111111111111111',
              'Content-Type: application/json',
           ));
           curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
           // EXECUTE:
           $result = curl_exec($curl);
           if(!$result){die("Connection Failure");}
           curl_close($curl);
           return $result;
        }

        $get_data = callAPI('GET', $url, false);
        $response = json_decode($get_data, true);
        $errors = $response['response']['errors'];
        $data = $response['response']['data'][0];
   
    }
} else {
    echo 'err';
}

if ($conn->query($sql) === TRUE) {
 
} else {
    
}
 
$conn->close();
	

	