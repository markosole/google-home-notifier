<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


$app = new \Slim\App;

// // Get all products
$app->get('/api/products', function(Request $request, Response $response){
  $sql = "SELECT storedDNS FROM storedns WHERE tb_id = '1'";

  try{
    // Get DB Object
    $db = new db();
    //Connect
    $db = $db->connect();
    $stmt = $db->query($sql);
    $products = $stmt->fetchAll(PDO::FETCH_OBJ);
    $db = null;
    
   echo json_encode($products);
  } catch(PDOException $e) {
    echo '{"error": {"text: '.$e->getMessage().'}';
  }

});

// // Get singe product
// $app->get('/api/product/{id}', function(Request $request, Response $response){
//   $id = $request->getAttribute('id');
//   $sql = "SELECT * FROM artikli WHERE id=$id";

//   try{
//     // Get DB Object
//     $db = new db();
//     //Connect

//     $db = $db->connect();
//     $stmt = $db->query($sql);
//     $product = $stmt->fetchAll(PDO::FETCH_OBJ);
//     $db = null;
      
//    echo json_encode($product);
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });

// // Get Banner
// $app->get('/api/banner', function(Request $request, Response $response){
//   $sql = "SELECT * FROM banner WHERE published='yes'";

//   try{
//     // Get DB Object
//     $db = new db();
//     //Connect

//     $db = $db->connect();
//     $stmt = $db->query($sql);
//     $banner = $stmt->fetchAll(PDO::FETCH_OBJ);
//     $db = null;
      
//    echo json_encode($banner);
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });

// // Get Cover image
// $app->get('/api/cover', function(Request $request, Response $response){
//   $sql = "SELECT * FROM cover WHERE published='yes'";

//   try{
//     // Get DB Object
//     $db = new db();
//     //Connect

//     $db = $db->connect();
//     $stmt = $db->query($sql);
//     $cover = $stmt->fetchAll(PDO::FETCH_OBJ);
//     $db = null;
      
//    echo json_encode($cover);
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });

// // Get Catalogues
// $app->get('/api/catalogue', function(Request $request, Response $response){
//   $sql = "SELECT * FROM katalozi WHERE published='yes'";

//   try{
//     // Get DB Object
//     $db = new db();
//     //Connect

//     $db = $db->connect();
//     $stmt = $db->query($sql);
//     $katalozi = $stmt->fetchAll(PDO::FETCH_OBJ);
//     $db = null;
      
//    echo json_encode($katalozi);
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });

// // Get News
// $app->get('/api/news', function(Request $request, Response $response){
//   $sql = "SELECT * FROM novosti WHERE published = 'yes' ORDER BY objavljeno_date DESC";

//   try{
//     // Get DB Object
//     $db = new db();   
//     $db = $db->connect();
//     $stmt = $db->query($sql);  
//     $novosti = $stmt->fetchAll(PDO::FETCH_OBJ);
//    // kill db
//     $db = null;  
//  echo json_encode($novosti);
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });


// // Get Maps data from Joomla database table
// $app->get('/api/mapsdata', function(Request $request, Response $response){
//   $sql = "SELECT params FROM swe01_modules WHERE id = 237";

//   try{
 
//     $mysqli = new mysqli("localhost", "cmbihco_cmnew", "Lozinka1234", "cmbihco_cmnew");
  
//     if ($result = $mysqli->query($sql)) {    
//         $row = $result->fetch_array(MYSQLI_ASSOC);
//         // Pull params JSON data and decode it $row["params"];
//         $pretvori= json_decode($row["params"]);
//         // Pull markers and decode from base64 into plain json data
//         echo base64_decode($pretvori->markes);
//         /* free result set */
//         $result->close();
        
//     } 
//     // close connection  
//     $mysqli->close(); 


//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });

// Insert singe product
$app->post('/api/product/dodaj', function(Request $request, Response $response){
  $storedDNS = $request->getParam('storedDNS');
   

  $sql = "INSERT INTO storedns (storedDNS) VALUES (:storedDNS)";

  try{
    // Get DB Object
    $db = new db();
    //Connect

    $db = $db->connect();
    $stmt = $db->prepare($sql);
   
    $stmt->bindParam(':storedDNS',$storedDNS);  

    $stmt->execute();

    echo '{"notice": {"text": "DNS redord added"}';
  } catch(PDOException $e) {
    echo '{"error": {"text: '.$e->getMessage().'}';
  }

});

// Update single product
$app->put('/api/product/update/{tb_id}', function(Request $request, Response $response){
  $id = $request->getAttribute('tb_id');
  $storedDNS = $request->getParam('storedDNS');
  

  $sql = "UPDATE storedns SET 
                 storedDNS = :storedDNS
           WHERE tb_id= $id";

  try{
    // Get DB Object
    $db = new db();
    //Connect

    $db = $db->connect();
    $stmt = $db->prepare($sql);
   
    $stmt->bindParam(':storedDNS',$storedDNS);
    

    $stmt->execute();

    echo '{"notice": {"text": "DNS data updated"}';
  } catch(PDOException $e) {
    echo '{"error": {"text: '.$e->getMessage().'}';
  }

});


// // Delete singe product
// $app->delete('/api/product/delete/{id}', function(Request $request, Response $response){
//   $id = $request->getAttribute('id');
//   $sql = "DELETE FROM artikli WHERE id=$id";

//   try{
//     // Get DB Object
//     $db = new db();
//     //Connect

//     $db = $db->connect();
//     $stmt = $db->prepare($sql);
//     $stmt->execute();
//     $db = null;
      
//    echo '{"notice": {"text": "Product deleted"}';
//   } catch(PDOException $e) {
//     echo '{"error": {"text: '.$e->getMessage().'}';
//   }

// });